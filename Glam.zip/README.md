# Glam Price Card + Admin Panel

- Public card (send to clients): `https://your-site.vercel.app`
- Admin panel (only you): `https://your-site.vercel.app/admin`

In the admin panel you can change your photo, name, WhatsApp number, social links
(Instagram, TikTok, Facebook, WhatsApp, YouTube), prices and categories, bank accounts,
payment note, and upload or delete gallery pictures and videos. Tap **Save** and the card updates right away.

## Deploy to Vercel (one-time setup, about 10 minutes)
1. Upload this folder to a new **GitHub** repository.
2. On **vercel.com**, go to Add New → Project → import the repo → **Deploy**.
3. In the project, open **Storage** → **Create** → **Blob**, choose **Public** access,
   then connect it to the project. This adds `BLOB_READ_WRITE_TOKEN` automatically.
4. Go to **Settings → Environment Variables** and add
   `ADMIN_PASSWORD` = a strong password of your choice.
5. Go to **Deployments** → ⋯ → **Redeploy** (so the new settings take effect).
6. Open `/admin`, log in, fill in your details, and tap **Save**.

## Local testing (optional)
`npm install && npm run dev`, then open http://localhost:8080/admin (password: admin123)
